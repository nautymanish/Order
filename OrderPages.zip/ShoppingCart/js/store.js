﻿//----------------------------------------------------------------
// store (contains the products)
//

//
function store() {
    this.products = [
       
        new product("Shirt", "Shirt", "Mens",2),
        new product("TShirt", "TShirt", "Mens", 2)
    ];
    this.dvaCaption = [
        "Negligible",
        "Low",
        "Average",
        "Good",
        "Great"
    ];
    this.dvaRange = [
        "below 5%",
        "between 5 and 10%",
        "between 10 and 20%",
        "between 20 and 40%",
        "above 40%"
    ];
}
store.prototype.getProduct = function (sku) {
    for (var i = 0; i < this.products.length; i++) {
        if (this.products[i].sku == sku)
            return this.products[i];
    }
    return null;
}
